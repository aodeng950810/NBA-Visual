self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7885348acb878d187aa16c7936b15f49",
    "url": "/index.html"
  },
  {
    "revision": "257335edc113b007ba1d",
    "url": "/static/css/2.9ddb28ea.chunk.css"
  },
  {
    "revision": "6bf6857442de9bd522d5",
    "url": "/static/css/main.6613353e.chunk.css"
  },
  {
    "revision": "257335edc113b007ba1d",
    "url": "/static/js/2.b2ce988f.chunk.js"
  },
  {
    "revision": "fa70fc0db5c9485dbb2462aea58119ce",
    "url": "/static/js/2.b2ce988f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6bf6857442de9bd522d5",
    "url": "/static/js/main.0861b378.chunk.js"
  },
  {
    "revision": "bc4a11c9ba67afa58f2e",
    "url": "/static/js/runtime-main.b3ec7c12.js"
  },
  {
    "revision": "9470e2d5c6c7f425edc8e9d8baebdb05",
    "url": "/static/media/nba-logoman-word-white.9470e2d5.svg"
  }
]);